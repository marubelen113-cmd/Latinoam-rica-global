import { Globe } from 'lucide-react';

export function Footer() {
  return (
    <footer className="relative border-t border-white/5">
      <div className="absolute inset-0 bg-dark-950" />
      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-12">
          {/* Brand */}
          <div>
            <div className="flex items-center gap-3 mb-4">
              <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-green-neon/20 to-green-primary/30 border border-green-neon/20 flex items-center justify-center">
                <Globe className="w-5 h-5 text-green-neon" />
              </div>
              <div>
                <span className="text-sm font-bold text-white tracking-wider block leading-tight">LATINOAMERICANA</span>
                <span className="text-[10px] font-medium text-green-neon tracking-[0.3em] block leading-tight">GLOBAL</span>
              </div>
            </div>
            <p className="text-sm text-gray-600 leading-relaxed max-w-xs">
              Soluciones tecnológicas de alto impacto para empresas que buscan excelencia.
            </p>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="text-sm font-semibold text-white mb-4 tracking-wider uppercase">Navegación</h4>
            <ul className="space-y-3">
              {[
                { label: 'Inicio', href: '#inicio' },
                { label: 'Servicios', href: '#servicios' },
                { label: 'Precios', href: '#precios' },
                { label: 'Nosotros', href: '#nosotros' },
                { label: 'Contacto', href: '#contacto' },
              ].map((link) => (
                <li key={link.label}>
                  <a
                    href={link.href}
                    className="text-sm text-gray-600 hover:text-green-neon transition-colors duration-300"
                  >
                    {link.label}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h4 className="text-sm font-semibold text-white mb-4 tracking-wider uppercase">Contacto</h4>
            <ul className="space-y-3">
              <li className="text-sm text-gray-600">(+58) 424 649 9019</li>
              <li className="text-sm text-gray-600">(+54) 375 140 4393</li>
              <li>
                <a
                  href="mailto:latinamerica58@gmail.com"
                  className="text-sm text-gray-600 hover:text-green-neon transition-colors duration-300"
                >
                  latinamerica58@gmail.com
                </a>
              </li>
            </ul>
          </div>
        </div>

        {/* Bottom */}
        <div className="mt-16 pt-8 border-t border-white/5 flex flex-col sm:flex-row items-center justify-between gap-4">
          <p className="text-xs text-gray-700">
            © {new Date().getFullYear()} Latinoamericana Global. Todos los derechos reservados.
          </p>
          <div className="flex items-center gap-1">
            <div className="w-1.5 h-1.5 rounded-full bg-green-neon/40" />
            <span className="text-xs text-gray-700">Soluciones IT de Alto Impacto</span>
          </div>
        </div>
      </div>
    </footer>
  );
}
