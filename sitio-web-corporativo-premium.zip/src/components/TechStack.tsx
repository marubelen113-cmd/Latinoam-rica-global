const technologies = [
  'JavaScript', 'HTML5', 'CSS3', 'Python', 'Node.js',
  'React', 'Next.js', 'APIs', 'Bases de Datos',
  'Ciberseguridad', 'Sistemas Financieros', 'TypeScript',
];

export function TechStack() {
  return (
    <section className="relative py-24 sm:py-32 overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-b from-dark-900 via-dark-800/50 to-dark-900" />
      
      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Description */}
        <div className="max-w-3xl mx-auto text-center mb-16">
          <h2 className="text-2xl sm:text-3xl md:text-4xl font-bold text-white mb-6 tracking-tight">
            Soluciones diseñadas para empresas que buscan{' '}
            <span className="text-gradient">excelencia tecnológica</span>
          </h2>
          <p className="text-base sm:text-lg text-gray-400 leading-relaxed">
            Combinamos las tecnologías más avanzadas del mercado con metodologías probadas para entregar soluciones que transforman operaciones y generan valor real.
          </p>
        </div>

        {/* Technologies */}
        <div className="flex flex-wrap justify-center gap-3 max-w-4xl mx-auto">
          {technologies.map((tech) => (
            <div
              key={tech}
              className="px-5 py-2.5 rounded-xl border border-white/5 bg-dark-800/40 text-sm font-medium text-gray-400 hover:text-green-neon hover:border-green-neon/20 hover:bg-green-neon/5 transition-all duration-300 cursor-default"
            >
              {tech}
            </div>
          ))}
        </div>

        {/* Stats */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-6 mt-20 max-w-4xl mx-auto">
          {[
            { number: '50+', label: 'Proyectos Entregados' },
            { number: '99%', label: 'Satisfacción' },
            { number: '24/7', label: 'Soporte Disponible' },
            { number: '12+', label: 'Tecnologías' },
          ].map((stat) => (
            <div key={stat.label} className="text-center p-6">
              <div className="text-3xl sm:text-4xl font-bold text-gradient mb-2">{stat.number}</div>
              <div className="text-xs sm:text-sm text-gray-500 font-medium">{stat.label}</div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
