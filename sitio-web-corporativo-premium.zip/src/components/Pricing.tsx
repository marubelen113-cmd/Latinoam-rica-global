import {
  Globe,
  Layout,
  Smartphone,
  Stethoscope,
  Landmark,
  Server,
  ShieldCheck,
} from 'lucide-react';

const plans = [
  {
    icon: Globe,
    title: 'Web Corporativa Profesional',
    price: '1,200 – 3,500',
    features: [
      'Sitios modernos y optimizados',
      'Enfocados en posicionamiento y conversión',
    ],
  },
  {
    icon: Layout,
    title: 'Plataforma Web Personalizada',
    price: '3,500 – 10,000',
    features: [
      'Sistemas escalables con panel administrativo',
      'Base de datos y funcionalidades avanzadas',
    ],
    highlighted: true,
  },
  {
    icon: Smartphone,
    title: 'Aplicación Móvil (iOS / Android)',
    price: '5,000 – 18,000',
    features: [
      'Aplicaciones nativas o híbridas',
      'Integración backend y seguridad avanzada',
    ],
  },
  {
    icon: Stethoscope,
    title: 'Sistema Médico',
    price: '6,000 – 20,000',
    subtitle: 'Citas + Gestión',
    features: [
      'Soluciones robustas para gestión médica',
      'Agendas, usuarios y control administrativo',
    ],
  },
  {
    icon: Landmark,
    title: 'Plataforma Financiera',
    price: '8,000 – 35,000',
    features: [
      'Sistemas financieros de alto estándar de seguridad',
      'Arquitectura escalable',
    ],
    highlighted: true,
  },
  {
    icon: Server,
    title: 'Backend / API Profesional',
    price: '2,000 – 8,000',
    features: [
      'Arquitectura sólida para aplicaciones web y móviles',
    ],
  },
  {
    icon: ShieldCheck,
    title: 'Auditoría y Seguridad Informática',
    price: '1,800 – 7,000',
    features: [
      'Evaluación de vulnerabilidades',
      'Fortalecimiento de infraestructura digital',
    ],
  },
];

export function Pricing() {
  return (
    <section id="precios" className="relative py-28 sm:py-36 overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-b from-dark-900 via-dark-800/30 to-dark-900" />
      <div className="absolute bottom-0 left-1/3 w-[500px] h-[500px] rounded-full bg-green-primary/4 blur-[150px]" />

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="max-w-3xl mx-auto text-center mb-20">
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full border border-green-neon/15 bg-green-neon/5 mb-6">
            <span className="text-xs font-medium text-green-neon tracking-wider uppercase">Inversión</span>
          </div>
          <h2 className="text-3xl sm:text-4xl md:text-5xl font-bold text-white mb-4 tracking-tight">
            Precios de Referencia
          </h2>
          <p className="text-sm sm:text-base text-gray-500 mb-6">
            Inversión estimada según alcance y complejidad
          </p>
          <p className="text-base sm:text-lg text-gray-400 leading-relaxed">
            Cada proyecto se cotiza de forma personalizada. Los siguientes valores representan rangos de inversión para proyectos internacionales.
          </p>
        </div>

        {/* Pricing Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {plans.map((plan) => (
            <div
              key={plan.title}
              className={`card-hover group relative p-8 rounded-2xl border overflow-hidden flex flex-col ${
                plan.highlighted
                  ? 'border-green-neon/25 bg-gradient-to-b from-green-neon/[0.04] to-dark-800/40'
                  : 'border-white/5 bg-dark-800/20'
              }`}
            >
              {plan.highlighted && (
                <div className="absolute top-0 left-0 right-0 h-[1px] bg-gradient-to-r from-transparent via-green-neon/50 to-transparent" />
              )}

              <div className="relative z-10 flex flex-col flex-1">
                <div className="w-12 h-12 rounded-xl bg-green-neon/5 border border-green-neon/10 flex items-center justify-center mb-5 group-hover:bg-green-neon/10 transition-all duration-500">
                  <plan.icon className="w-5 h-5 text-green-neon/70 group-hover:text-green-neon transition-colors" />
                </div>

                <h3 className="text-base font-semibold text-white mb-1">{plan.title}</h3>
                {plan.subtitle && (
                  <p className="text-xs text-gray-500 mb-4">{plan.subtitle}</p>
                )}
                {!plan.subtitle && <div className="mb-4" />}

                <div className="mb-1">
                  <span className="text-xs text-gray-500 font-medium">Inversión estimada</span>
                </div>
                <div className="flex items-baseline gap-1 mb-6">
                  <span className="text-2xl sm:text-3xl font-bold text-gradient">${plan.price}</span>
                  <span className="text-sm text-gray-500 font-medium">USD</span>
                </div>

                <ul className="space-y-3 mb-8 flex-1">
                  {plan.features.map((feature) => (
                    <li key={feature} className="flex items-start gap-3">
                      <div className="w-1.5 h-1.5 rounded-full bg-green-neon/50 mt-1.5 shrink-0" />
                      <span className="text-sm text-gray-500 group-hover:text-gray-400 transition-colors">{feature}</span>
                    </li>
                  ))}
                </ul>

                <a
                  href="#contacto"
                  className={`w-full py-3 px-6 rounded-xl text-sm font-semibold text-center transition-all duration-300 block ${
                    plan.highlighted
                      ? 'bg-gradient-to-r from-green-neon to-green-neon-dim text-dark-950 hover:shadow-lg hover:shadow-green-neon/20'
                      : 'border border-white/10 text-white hover:border-green-neon/30 hover:bg-green-neon/5'
                  }`}
                >
                  Solicitar cotización
                </a>
              </div>
            </div>
          ))}
        </div>

        {/* Nota final */}
        <div className="max-w-3xl mx-auto text-center mt-16">
          <p className="text-sm text-gray-500 leading-relaxed">
            Los valores pueden variar según integración, nivel de personalización y requerimientos específicos.
          </p>
          <p className="text-sm text-gray-400 mt-2">
            Solicite una reunión para recibir una propuesta detallada.
          </p>
        </div>
      </div>
    </section>
  );
}
