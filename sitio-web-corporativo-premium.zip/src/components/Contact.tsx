import { useState } from 'react';
import { Send, Phone, Mail, MessageCircle } from 'lucide-react';

export function Contact() {
  const [formData, setFormData] = useState({
    nombre: '',
    empresa: '',
    email: '',
    mensaje: '',
  });
  const [submitted, setSubmitted] = useState(false);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Build mailto or WhatsApp link
    const subject = `Consulta de ${formData.nombre} - ${formData.empresa}`;
    const body = `Nombre: ${formData.nombre}\nEmpresa: ${formData.empresa}\nEmail: ${formData.email}\n\nMensaje:\n${formData.mensaje}`;
    window.open(
      `mailto:latinamerica58@gmail.com?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`
    );
    setSubmitted(true);
    setTimeout(() => setSubmitted(false), 3000);
  };

  return (
    <section id="contacto" className="relative py-28 sm:py-36 overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-b from-dark-900 via-dark-950 to-dark-950" />
      <div className="absolute top-1/3 left-1/3 w-[500px] h-[500px] rounded-full bg-green-primary/4 blur-[150px]" />

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="max-w-3xl mx-auto text-center mb-20">
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full border border-green-neon/15 bg-green-neon/5 mb-6">
            <span className="text-xs font-medium text-green-neon tracking-wider uppercase">Contacto</span>
          </div>
          <h2 className="text-3xl sm:text-4xl md:text-5xl font-bold text-white mb-6 tracking-tight">
            Hablemos de su proyecto
          </h2>
          <p className="text-base sm:text-lg text-gray-400 leading-relaxed">
            Estamos listos para ayudarle a transformar su visión en una solución tecnológica de alto impacto.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-5 gap-12 max-w-6xl mx-auto">
          {/* Contact Info */}
          <div className="lg:col-span-2 space-y-8">
            <div>
              <h3 className="text-xl font-semibold text-white mb-6">Información de contacto</h3>
              <div className="space-y-6">
                {/* WhatsApp */}
                <a
                  href="https://wa.me/584246499019"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="group flex items-start gap-4 p-4 rounded-xl border border-white/5 bg-dark-800/20 hover:border-green-neon/20 hover:bg-green-neon/5 transition-all duration-300"
                >
                  <div className="w-12 h-12 rounded-xl bg-green-neon/5 border border-green-neon/10 flex items-center justify-center shrink-0 group-hover:bg-green-neon/10 transition-all">
                    <MessageCircle className="w-5 h-5 text-green-neon" />
                  </div>
                  <div>
                    <p className="text-sm font-medium text-white mb-1">WhatsApp</p>
                    <p className="text-sm text-gray-500">(+58) 424 649 9019</p>
                    <p className="text-sm text-gray-500">(+54) 375 140 4393</p>
                  </div>
                </a>

                {/* Phone */}
                <a
                  href="tel:+584246499019"
                  className="group flex items-start gap-4 p-4 rounded-xl border border-white/5 bg-dark-800/20 hover:border-green-neon/20 hover:bg-green-neon/5 transition-all duration-300"
                >
                  <div className="w-12 h-12 rounded-xl bg-green-neon/5 border border-green-neon/10 flex items-center justify-center shrink-0 group-hover:bg-green-neon/10 transition-all">
                    <Phone className="w-5 h-5 text-green-neon" />
                  </div>
                  <div>
                    <p className="text-sm font-medium text-white mb-1">Teléfono</p>
                    <p className="text-sm text-gray-500">(+58) 424 649 9019</p>
                  </div>
                </a>

                {/* Email */}
                <a
                  href="mailto:latinamerica58@gmail.com"
                  className="group flex items-start gap-4 p-4 rounded-xl border border-white/5 bg-dark-800/20 hover:border-green-neon/20 hover:bg-green-neon/5 transition-all duration-300"
                >
                  <div className="w-12 h-12 rounded-xl bg-green-neon/5 border border-green-neon/10 flex items-center justify-center shrink-0 group-hover:bg-green-neon/10 transition-all">
                    <Mail className="w-5 h-5 text-green-neon" />
                  </div>
                  <div>
                    <p className="text-sm font-medium text-white mb-1">Email</p>
                    <p className="text-sm text-gray-500">latinamerica58@gmail.com</p>
                  </div>
                </a>
              </div>
            </div>
          </div>

          {/* Contact Form */}
          <div className="lg:col-span-3">
            <form onSubmit={handleSubmit} className="p-8 sm:p-10 rounded-2xl border border-white/5 bg-dark-800/20 backdrop-blur-sm">
              <div className="space-y-6">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                  <div>
                    <label htmlFor="nombre" className="block text-sm font-medium text-gray-400 mb-2">
                      Nombre
                    </label>
                    <input
                      type="text"
                      id="nombre"
                      name="nombre"
                      required
                      value={formData.nombre}
                      onChange={handleChange}
                      className="w-full px-4 py-3.5 rounded-xl border border-white/5 bg-dark-900/50 text-white text-sm placeholder:text-gray-600 focus:outline-none focus:border-green-neon/30 focus:ring-1 focus:ring-green-neon/20 transition-all duration-300"
                      placeholder="Su nombre"
                    />
                  </div>
                  <div>
                    <label htmlFor="empresa" className="block text-sm font-medium text-gray-400 mb-2">
                      Empresa
                    </label>
                    <input
                      type="text"
                      id="empresa"
                      name="empresa"
                      value={formData.empresa}
                      onChange={handleChange}
                      className="w-full px-4 py-3.5 rounded-xl border border-white/5 bg-dark-900/50 text-white text-sm placeholder:text-gray-600 focus:outline-none focus:border-green-neon/30 focus:ring-1 focus:ring-green-neon/20 transition-all duration-300"
                      placeholder="Nombre de su empresa"
                    />
                  </div>
                </div>

                <div>
                  <label htmlFor="email" className="block text-sm font-medium text-gray-400 mb-2">
                    Email
                  </label>
                  <input
                    type="email"
                    id="email"
                    name="email"
                    required
                    value={formData.email}
                    onChange={handleChange}
                    className="w-full px-4 py-3.5 rounded-xl border border-white/5 bg-dark-900/50 text-white text-sm placeholder:text-gray-600 focus:outline-none focus:border-green-neon/30 focus:ring-1 focus:ring-green-neon/20 transition-all duration-300"
                    placeholder="correo@empresa.com"
                  />
                </div>

                <div>
                  <label htmlFor="mensaje" className="block text-sm font-medium text-gray-400 mb-2">
                    Mensaje
                  </label>
                  <textarea
                    id="mensaje"
                    name="mensaje"
                    required
                    rows={5}
                    value={formData.mensaje}
                    onChange={handleChange}
                    className="w-full px-4 py-3.5 rounded-xl border border-white/5 bg-dark-900/50 text-white text-sm placeholder:text-gray-600 focus:outline-none focus:border-green-neon/30 focus:ring-1 focus:ring-green-neon/20 transition-all duration-300 resize-none"
                    placeholder="Cuéntenos sobre su proyecto..."
                  />
                </div>

                <button
                  type="submit"
                  className="group w-full py-4 px-8 rounded-xl text-sm font-semibold text-dark-950 bg-gradient-to-r from-green-neon to-green-neon-dim hover:shadow-xl hover:shadow-green-neon/20 transition-all duration-300 hover:scale-[1.02] flex items-center justify-center gap-2"
                >
                  {submitted ? (
                    '✓ Mensaje enviado'
                  ) : (
                    <>
                      Enviar consulta
                      <Send className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
                    </>
                  )}
                </button>
              </div>
            </form>
          </div>
        </div>
      </div>
    </section>
  );
}
