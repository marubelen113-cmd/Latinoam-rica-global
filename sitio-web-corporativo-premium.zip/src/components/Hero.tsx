import { ArrowRight, ChevronDown } from 'lucide-react';

export function Hero() {
  return (
    <section id="inicio" className="relative min-h-screen flex items-center justify-center overflow-hidden">
      {/* Background Effects */}
      <div className="absolute inset-0 bg-grid" />
      <div className="absolute inset-0 bg-gradient-to-b from-dark-950 via-dark-950/95 to-dark-900" />

      {/* Floating Nodes */}
      <div className="absolute top-1/4 left-1/4 w-2 h-2 rounded-full bg-green-neon/30 animate-float" />
      <div className="absolute top-1/3 right-1/3 w-1.5 h-1.5 rounded-full bg-green-neon/20 animate-float-delay" />
      <div className="absolute bottom-1/3 left-1/3 w-1 h-1 rounded-full bg-green-neon/25 animate-float-delay-2" />
      <div className="absolute top-2/3 right-1/4 w-2.5 h-2.5 rounded-full bg-green-neon/15 animate-float" />
      <div className="absolute top-1/2 left-[15%] w-1.5 h-1.5 rounded-full bg-green-neon/20 animate-float-delay" />

      {/* Gradient orbs */}
      <div className="absolute top-1/4 right-1/4 w-[500px] h-[500px] rounded-full bg-green-primary/5 blur-[120px]" />
      <div className="absolute bottom-1/4 left-1/4 w-[400px] h-[400px] rounded-full bg-green-neon/3 blur-[100px]" />

      {/* Connection lines */}
      <svg className="absolute inset-0 w-full h-full opacity-[0.04]" xmlns="http://www.w3.org/2000/svg">
        <line x1="10%" y1="20%" x2="40%" y2="50%" stroke="#00e88f" strokeWidth="0.5" />
        <line x1="60%" y1="15%" x2="85%" y2="45%" stroke="#00e88f" strokeWidth="0.5" />
        <line x1="20%" y1="70%" x2="50%" y2="40%" stroke="#00e88f" strokeWidth="0.5" />
        <line x1="70%" y1="80%" x2="90%" y2="50%" stroke="#00e88f" strokeWidth="0.5" />
        <line x1="30%" y1="30%" x2="70%" y2="70%" stroke="#00e88f" strokeWidth="0.3" />
      </svg>

      <div className="relative z-10 max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
        {/* Badge */}
        <div className="animate-fade-in-up inline-flex items-center gap-2 px-4 py-2 rounded-full border border-green-neon/20 bg-green-neon/5 mb-8">
          <div className="w-2 h-2 rounded-full bg-green-neon animate-pulse" />
          <span className="text-xs font-medium text-green-neon tracking-wider uppercase">
            Soluciones IT de Alto Impacto
          </span>
        </div>

        {/* Title */}
        <h1 className="animate-fade-in-up-delay text-4xl sm:text-5xl md:text-7xl lg:text-8xl font-black text-white tracking-tight leading-[0.9] mb-4">
          LATINOAMERICANA
          <br />
          <span className="text-gradient">GLOBAL</span>
        </h1>

        {/* Subtitle */}
        <p className="animate-fade-in-up-delay-2 max-w-2xl mx-auto text-base sm:text-lg md:text-xl text-gray-400 leading-relaxed mt-8 mb-12 font-light">
          Desarrollo de Software, Aplicaciones Web y Móviles, Plataformas Financieras y Sistemas de Seguridad.
        </p>

        {/* CTA Buttons */}
        <div className="animate-fade-in-up-delay-3 flex flex-col sm:flex-row items-center justify-center gap-4">
          <a
            href="#contacto"
            className="group w-full sm:w-auto px-8 py-4 text-sm font-semibold text-dark-950 bg-gradient-to-r from-green-neon to-green-neon-dim rounded-2xl hover:shadow-xl hover:shadow-green-neon/20 transition-all duration-300 hover:scale-105 flex items-center justify-center gap-2"
          >
            Agendar reunión
            <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
          </a>
          <a
            href="#servicios"
            className="group w-full sm:w-auto px-8 py-4 text-sm font-semibold text-white border border-white/10 hover:border-green-neon/30 rounded-2xl transition-all duration-300 hover:bg-green-neon/5 flex items-center justify-center gap-2"
          >
            Ver servicios
            <ChevronDown className="w-4 h-4 group-hover:translate-y-1 transition-transform" />
          </a>
        </div>
      </div>

      {/* Bottom fade */}
      <div className="absolute bottom-0 left-0 right-0 h-32 bg-gradient-to-t from-dark-900 to-transparent" />

      {/* Scroll indicator */}
      <div className="absolute bottom-8 left-1/2 -translate-x-1/2 flex flex-col items-center gap-2 animate-fade-in-up-delay-3">
        <span className="text-[10px] font-medium text-gray-600 tracking-widest uppercase">Scroll</span>
        <div className="w-[1px] h-8 bg-gradient-to-b from-green-neon/40 to-transparent" />
      </div>
    </section>
  );
}
