import {
  Code2,
  Globe,
  Layout,
  Smartphone,
  Server,
  Stethoscope,
  Landmark,
  ShieldCheck,
  Cog,
} from 'lucide-react';

const services = [
  {
    icon: Code2,
    title: 'Desarrollo de Software a Medida',
    description:
      'Creamos soluciones de software personalizadas que se adaptan exactamente a los procesos y necesidades únicas de su organización.',
  },
  {
    icon: Globe,
    title: 'Páginas Web Corporativas',
    description:
      'Diseño y desarrollo de sitios web profesionales que proyectan la identidad y solidez de su empresa a nivel global.',
  },
  {
    icon: Layout,
    title: 'Aplicaciones Web',
    description:
      'Plataformas web robustas y escalables con interfaces intuitivas para gestión empresarial, e-commerce y más.',
  },
  {
    icon: Smartphone,
    title: 'Aplicaciones Móviles',
    description:
      'Apps nativas y multiplataforma de alto rendimiento para iOS y Android con experiencia de usuario premium.',
  },
  {
    icon: Server,
    title: 'Backends y APIs',
    description:
      'Arquitecturas de servidor seguras, eficientes y documentadas. APIs RESTful y GraphQL para integración total.',
  },
  {
    icon: Stethoscope,
    title: 'Sistemas de Citas Médicas',
    description:
      'Plataformas especializadas para gestión de citas, expedientes médicos y telemedicina con máxima seguridad.',
  },
  {
    icon: Landmark,
    title: 'Plataformas Financieras',
    description:
      'Sistemas fintech seguros para procesamiento de pagos, análisis financiero y gestión de portafolios.',
  },
  {
    icon: ShieldCheck,
    title: 'Ciberseguridad',
    description:
      'Auditorías de seguridad, protección de datos, implementación de firewalls y protocolos de seguridad avanzados.',
  },
  {
    icon: Cog,
    title: 'Automatización de Procesos',
    description:
      'Optimización y automatización de flujos de trabajo empresariales para maximizar eficiencia y reducir costos.',
  },
];

export function Services() {
  return (
    <section id="servicios" className="relative py-28 sm:py-36 overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-b from-dark-900 via-dark-950 to-dark-900" />
      <div className="absolute top-1/2 -translate-y-1/2 right-0 w-[500px] h-[500px] rounded-full bg-green-primary/4 blur-[150px]" />

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="max-w-3xl mx-auto text-center mb-20">
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full border border-green-neon/15 bg-green-neon/5 mb-6">
            <span className="text-xs font-medium text-green-neon tracking-wider uppercase">Nuestras soluciones</span>
          </div>
          <h2 className="text-3xl sm:text-4xl md:text-5xl font-bold text-white mb-6 tracking-tight">
            Servicios
          </h2>
          <p className="text-base sm:text-lg text-gray-400 leading-relaxed">
            Ofrecemos un portafolio completo de soluciones tecnológicas diseñadas para impulsar la transformación digital de su empresa.
          </p>
        </div>

        {/* Services Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {services.map((service) => (
            <div
              key={service.title}
              className="card-hover group relative p-8 rounded-2xl border border-white/5 bg-dark-800/20 backdrop-blur-sm overflow-hidden"
            >
              {/* Hover glow */}
              <div className="absolute inset-0 bg-gradient-to-br from-green-neon/0 to-green-neon/0 group-hover:from-green-neon/[0.02] group-hover:to-green-neon/[0.05] transition-all duration-500 rounded-2xl" />

              <div className="relative z-10">
                <div className="w-14 h-14 rounded-2xl bg-green-neon/5 border border-green-neon/10 flex items-center justify-center mb-6 group-hover:bg-green-neon/10 group-hover:border-green-neon/25 transition-all duration-500">
                  <service.icon className="w-6 h-6 text-green-neon/70 group-hover:text-green-neon transition-colors duration-500" />
                </div>
                <h3 className="text-lg font-semibold text-white mb-3 group-hover:text-green-neon/90 transition-colors duration-300">
                  {service.title}
                </h3>
                <p className="text-sm text-gray-500 leading-relaxed group-hover:text-gray-400 transition-colors duration-300">
                  {service.description}
                </p>
              </div>

              {/* Corner accent */}
              <div className="absolute top-0 right-0 w-20 h-20 bg-gradient-to-bl from-green-neon/[0.03] to-transparent rounded-bl-3xl opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
