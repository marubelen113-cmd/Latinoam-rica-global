import { Shield, Zap, Target, TrendingUp } from 'lucide-react';

const values = [
  {
    icon: Shield,
    title: 'Seguridad',
    description: 'Protección de datos y sistemas con estándares internacionales de ciberseguridad.',
  },
  {
    icon: Zap,
    title: 'Rendimiento',
    description: 'Sistemas optimizados para máxima velocidad y eficiencia operativa.',
  },
  {
    icon: Target,
    title: 'Precisión',
    description: 'Soluciones diseñadas con enfoque estratégico y orientadas a resultados.',
  },
  {
    icon: TrendingUp,
    title: 'Escalabilidad',
    description: 'Arquitecturas preparadas para crecer con su organización.',
  },
];

export function AboutSection() {
  return (
    <section id="nosotros" className="relative py-28 sm:py-36 overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-b from-dark-900 via-dark-950 to-dark-900" />

      {/* Subtle background effect */}
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[600px] h-[600px] rounded-full bg-green-primary/3 blur-[150px]" />

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="max-w-3xl mx-auto text-center mb-20">
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full border border-green-neon/15 bg-green-neon/5 mb-6">
            <span className="text-xs font-medium text-green-neon tracking-wider uppercase">Quiénes somos</span>
          </div>
          <h2 className="text-3xl sm:text-4xl md:text-5xl font-bold text-white mb-8 tracking-tight">
            Nosotros
          </h2>
          <div className="space-y-6">
            <p className="text-base sm:text-lg text-gray-400 leading-relaxed">
              <span className="text-white font-semibold">Latinoamericana Global</span> es una firma especializada en soluciones tecnológicas de alto impacto para empresas en crecimiento y organizaciones que requieren sistemas robustos, seguros y escalables.
            </p>
            <p className="text-base sm:text-lg text-gray-400 leading-relaxed">
              Trabajamos con estándares internacionales de desarrollo, priorizando seguridad, rendimiento y diseño estratégico.
            </p>
            <p className="text-base sm:text-lg text-green-neon/80 font-medium leading-relaxed">
              Enfocados en resultados reales y soluciones escalables.
            </p>
          </div>
        </div>

        {/* Divider */}
        <div className="flex items-center gap-4 max-w-xs mx-auto mb-20">
          <div className="flex-1 h-[1px] bg-gradient-to-r from-transparent to-green-neon/30" />
          <div className="w-2 h-2 rounded-full bg-green-neon/40" />
          <div className="flex-1 h-[1px] bg-gradient-to-l from-transparent to-green-neon/30" />
        </div>

        {/* Values Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {values.map((value) => (
            <div
              key={value.title}
              className="group p-8 rounded-2xl border border-white/5 bg-dark-800/30 hover:bg-dark-800/60 hover:border-green-neon/20 transition-all duration-500"
            >
              <div className="w-14 h-14 rounded-2xl bg-green-neon/5 border border-green-neon/10 flex items-center justify-center mb-6 group-hover:bg-green-neon/10 group-hover:border-green-neon/20 transition-all duration-500">
                <value.icon className="w-6 h-6 text-green-neon" />
              </div>
              <h3 className="text-lg font-semibold text-white mb-3">{value.title}</h3>
              <p className="text-sm text-gray-500 leading-relaxed">{value.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
